import { useState } from "react"
import { Link } from "react-router-dom"
import { HeaderDropdown } from "./header/header-dropdown"

export const Header = () => {
    const [dropdownState, setDropdownState] = useState(false);

    return (
        <header className={`header ${dropdownState ? 'active' : ''}`}>
            <div className='header__row'>
                <Link to='/' className='logo__wrapper'>
                    <img src='./images/svg/logo.svg' alt='logo' />
                </Link>
                <nav>
                    <ul>
                        <li><Link to='#'>Как зарядиться</Link></li>
                        <li><Link to='#'>Цена</Link></li>
                        <li><Link to='#'>Партнерам</Link></li>
                        <li><Link to='#'>Реклама</Link></li>
                    </ul>
                </nav>
                <div className='header__btns'>
                    <button className='btn-green'>
                        Зарядись онлайн
                    </button>
                    <button className='header__burger' onClick={() => setDropdownState(!dropdownState)}>
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>
            <div className='header__row header__dropdown'>
                <HeaderDropdown />
            </div>
        </header>
    )
}