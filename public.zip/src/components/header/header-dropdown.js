import { Link } from "react-router-dom"

export const HeaderDropdown = () => {
    return (
        <>
            <div className='dropdown__side left'>
                <div className='dropdown__col'>
                    <h6>Зарядка электромобиля</h6>
                    <ul>
                        <li><Link to='#'>Личный кабинет</Link></li>
                        <li><Link to='#'>Стоимость зарядки</Link></li>
                        <li><Link to='#'>Помогаем зарядится / Впервые тут?</Link></li>
                        <li><Link to='#'>Скачать приложение для зарядки</Link></li>
                    </ul>
                </div>
                <div className='dropdown__col'>
                    <h6>Решения для бизнеса</h6>
                    <ul>
                        <li><Link to='#'>Зарядная карта</Link></li>
                        <li><Link to='#'>Стать партнером</Link></li>
                        <li><Link to='#'>Рекламные возможности</Link></li>
                    </ul>
                </div>
                <div className='dropdown__col'>
                    <h6>Маланка</h6>
                    <ul>
                        <li><Link to='#'>Миссия</Link></li>
                        <li><Link to='#'>Новости</Link></li>
                        <li><Link to='#'>Калькулятор экономии</Link></li>
                        <li><Link to='#'>Свяжитесь с нами</Link></li>
                    </ul>
                </div>
            </div>
            <div className='dropdown__side right'>
                <a href='#'>BY</a>
                <a href='#'>RU</a>
                <a href='#'>EN</a>
            </div>
        </>
    )
}