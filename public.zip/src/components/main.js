import { MainBlock } from "./main/main-block"
import { MainMap } from "./main/main-map"
import { MainNews } from "./main/main-news"
import { MainTitle } from "./main/main-title"

export const Main = () => {
    return (
        <main>
            <MainTitle />
            <MainMap />
            <MainBlock />
            <MainNews />
            <MainBlock />
        </main>
    )
}