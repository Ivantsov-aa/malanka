export const MainBlock = () => {
    return (
        <div className='main__block-wrapper'>
            <section className='main__block'>
                <div>
                    <h2>Заголовок</h2>
                    <p className='text'>Наше приложение - Ваш пропуск в мир будущего. Полный контроль процесса зарядки электромобиля.
                        Скачайте и откройте для себя способ заправким 21 века!</p>
                    <ul>
                        <li className='list-text'>
                            Следите за состоянием зарядного устройства и управляйте им удаленно с мобильного телефона, смарт-часов или web-портала
                        </li>
                        <li className='list-text'>
                            Просматривайте статистику зарядки в реальном времени
                        </li>
                        <li className='list-text'>
                            Контролируйте потребление электроэнергии и расходы с помощью графиков и диаграм
                        </li>
                    </ul>
                    <button className='btn-green'>Мобильное приложение</button>
                </div>
                <img src='./images/main-1.png' alt='main-block' />
            </section>
        </div>
    )
}