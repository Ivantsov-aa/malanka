import { useEffect, useRef } from "react"

export const MainTitle = () => {
    const titleBgRef = useRef();
    const titleImageRef = useRef();
    const scrollFunc = () => {
        let scrollTop = window.scrollY;
        let titleHeight = titleBgRef.current.getBoundingClientRect().height;

        let value = 1 - (titleHeight - scrollTop) / titleHeight;

        titleBgRef.current.style.backgroundColor = `rgba(0, 0, 0, ${value})`;
        titleImageRef.current.style.backgroundPosition = `50px -${scrollTop * 1.6}px`;
    }

    useEffect(() => {
        window.addEventListener('scroll', scrollFunc);

        return () => {
            window.removeEventListener('scroll', scrollFunc);
        }
    }, []);

    return (
        <div className='main__title-wrapper'>
            <section className='main__title'>
                <div className='title-bg' ref={titleBgRef}></div>
                <div>
                    <h1>Маланка - крупнейшая сеть электрозадярных станций Беларуси</h1>
                    <ul>
                        <li className='list-text'>
                            Следите за состоянием зарядного устройства и управляйте им удаленно с мобильного телефона, смарт-часов или web-портала
                        </li>
                        <li className='list-text'>
                            Просматривайте статистику зарядки в реальном времени
                        </li>
                        <li className='list-text'>
                            Контролируйте потребление электроэнергии и расходы с помощью графиков и диаграм
                        </li>
                        <li className='list-text'>
                            Получайте Push-уведомления об окончании зарядки, о запланированной зарядки, обновлениях и т.д
                        </li>
                    </ul>
                    <div className='app-links'>
                        <a href='https://apps.apple.com/by/app/malanka-new/id6444453443'>
                            <svg width="27" height="30" viewBox="0 0 27 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M22.1271 28.4643C20.4529 30.008 18.625 29.7643 16.8654 29.033C15.0033 28.2855 13.295 28.253 11.3304 29.033C8.87042 30.0405 7.57208 29.748 6.10292 28.4643C-2.23375 20.2905 -1.00375 7.84303 8.46042 7.38803C10.7667 7.50178 12.3725 8.59053 13.7221 8.68803C15.7379 8.29803 17.6683 7.17678 19.8208 7.32303C22.4004 7.51803 24.3479 8.49303 25.6292 10.248C20.2992 13.2868 21.5633 19.9655 26.4492 21.8343C25.4754 24.2718 24.2113 26.693 22.11 28.4805L22.1271 28.4643ZM13.5513 7.29053C13.295 3.66678 16.3871 0.676777 19.9404 0.384277C20.4358 4.57678 15.9429 7.69678 13.5513 7.29053Z" fill="white" />
                            </svg>
                            <div>
                                <p>Download on the</p>
                                <p>App Store</p>
                            </div>
                        </a>
                        <a href='https://play.google.com/store/apps/details?id=by.malankabn.app'>
                            <svg width="25" height="28" viewBox="0 0 25 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18.4388 18.1357C21.6087 16.3794 24.0117 15.0411 24.2188 14.9371C24.8814 14.5815 25.5657 13.6405 24.2188 12.9095C23.784 12.6796 21.4427 11.383 18.4388 9.71088L14.2745 13.9545L18.4388 18.1356V18.1357Z" fill="#FFD900" />
                                <path d="M14.2745 13.9545L1.01504 27.439C1.32627 27.4806 1.67764 27.3973 2.09189 27.1675C2.96162 26.6871 12.1815 21.6065 18.4388 18.1366L14.2745 13.9545Z" fill="#F43249" />
                                <path d="M14.2745 13.9545L18.4388 9.73174C18.4388 9.73174 3.02451 1.24339 2.0919 0.742312C1.74053 0.532323 1.34678 0.469947 0.994434 0.532323L14.2745 13.9545Z" fill="#00EE76" />
                                <path d="M14.2745 13.9545L0.994434 0.532349C0.455469 0.658086 0 1.13857 0 2.12121V25.8502C0 26.7495 0.352441 27.3973 1.01504 27.4598L14.2745 13.9545Z" fill="#00D3FF" />
                            </svg>
                            <div>
                                <p>Get it on</p>
                                <p>Coogle Play</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div className='title__image' ref={titleImageRef}>
                </div>
            </section>
        </div>
    )
}