import { useState } from "react";
import { Link } from "react-router-dom";

const sectionsContent = {
    news: [
        {
            id: 1,
            title: 'Malanka напоминает об основных факторах, которые влияют на запас хода электромобиля',
            img: './images/news/news-1.png',
            path: '#'
        },
        {
            id: 2,
            title: 'Malanka напоминает основные правила поведения на общественных зарядных точках',
            img: './images/news/news-2.png',
            path: '#'
        },
        {
            id: 3,
            title: 'Электромобили в каршеринге: сколько стоят и выгодны ли для бизнеса',
            img: './images/news/news-3.png',
            path: '#'
        }
    ],
    clients: [
        {
            id: 4,
            title: 'Зарядные станции Malanka для любых электромобилей',
            img: './images/news/news-4.jpg',
            path: '#'
        },
        {
            id: 5,
            title: 'Преимущества современных зарядных станций',
            img: './images/news/news-5.jpg',
            path: '#'
        },
        {
            id: 6,
            title: 'Почему выбирают нас',
            img: './images/news/news-6.jpg',
            path: '#'
        }
    ]
};

export const MainNews = () => {
    const [chosenSection, setChosenSection] = useState(1);

    return (
        <section className='main__news-wrapper'>
            <section className='news'>
                <h2>Узнайте больше</h2>
                <div className='news__toggle'>
                    <button className={`btn-gray ${chosenSection === 1 ? 'active' : ''}`} onClick={() => setChosenSection(1)}>Покупателю</button>
                    <button className={`btn-gray ${chosenSection === 2 ? 'active' : ''}`} onClick={() => setChosenSection(2)}> Новости</button>
                </div>
                <div className='news__feed'>
                    {chosenSection === 1 ?
                        sectionsContent.clients.map(item => (
                            <Link to={item.path} className='news__link' key={item.id}>
                                <div className='img__wrapper'>
                                    <img src={item.img} loading='lazy' alt='news-cover' />
                                </div>
                                <h4>{item.title}</h4>
                            </Link>
                        ))
                        :
                        sectionsContent.news.map(item => (
                            <Link to={item.path} className='news__link' key={item.id}>
                                <div className='img__wrapper'>
                                    <img src={item.img} loading='lazy' alt='news-cover' />
                                </div>
                                <h4>{item.title}</h4>
                            </Link>
                        ))
                    }
                </div>
            </section>
        </section >
    )
}